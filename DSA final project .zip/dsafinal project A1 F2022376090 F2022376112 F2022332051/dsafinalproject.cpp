//Sara Akmal F2022376090
//Hafsa Rehman F2022376112
//Rayyan Ahsan F2022332051

#include <iostream>
#include <string>
#include <fstream>
#include <queue>

using namespace std;

ofstream MyFile("filename.txt");

class Guest {
public:
    int ID;
    string First_name, Second_name;
    Guest* next;
    Guest* prev;

    Guest(int ID, string First_name, string Second_name)
        : ID(ID), First_name(First_name), Second_name(Second_name), next(NULL), prev(NULL) {}
};

void addathead(Guest*& head, int ID, string First_name, string Second_name) {
    Guest* temp = new Guest(ID, First_name, Second_name);
    temp->next = head;
    if (head != NULL) {
        head->prev = temp;
    }
    head = temp;
}

void deletefromtail(Guest*& tail) {
    if (tail != NULL) {
        Guest* del = tail;
        tail = tail->prev;
        if (tail != NULL) {
            tail->next = NULL;
        }
        delete del;
    }
}

void sortrecords(Guest*& head) {
    if (head != NULL) {
        Guest* current = head;
        while (current->next != NULL) {
            Guest* perv = current->next;
            while (perv != NULL) {
                if ((current->ID) > (perv->ID)) {
                    swap(current->ID, perv->ID);
                }
                perv = perv->next;
            }
            current = current->next;
        }
    }
}

void searchinLL(Guest*& head, int cni) {
    if (head != NULL) {
        Guest* temp = head;
        while (temp != NULL) {
            if (temp->ID == cni) {
                cout << "ID Found" << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "ID Not Found" << endl;
    }
}

void display(Guest*& head) {
    Guest* temp = head;
    while (temp != NULL) {
        cout << "ID: " << temp->ID << endl;
        cout << "First Name: " << temp->First_name << endl;
        cout << "Last Name: " << temp->Second_name << endl;
        cout << endl;
        cout << endl;
        temp = temp->next;
    }
}

class Hotel {
public:
    int no_of_family_members;
    int time_of_stay;
    int outstanding_payment;

    Hotel* next;
    Hotel* prev;

    Hotel(int no_of_family_members, int time_of_stay)
        : no_of_family_members(no_of_family_members), time_of_stay(time_of_stay), outstanding_payment(0), next(NULL), prev(NULL) {}
};

void addathead(Hotel*& head, int no_of_family_members, int time_of_stay) {
    Hotel* temp = new Hotel(no_of_family_members, time_of_stay);
    temp->next = head;
    if (head != NULL) {
        head->prev = temp;
    }
    head = temp;
}

void deletefromtail(Hotel*& tail) {
    if (tail != NULL) {
        Hotel* del = tail;
        tail = tail->prev;
        if (tail != NULL) {
            tail->next = NULL;
        }
        delete del;
    }
}

void display(Hotel*& head) {
    Hotel* temp = head;
    while (temp != NULL) {
        cout << "Outstanding Payment-> " << temp->outstanding_payment << endl;
        cout << endl;
        cout << endl;
        temp = temp->next;
    }
}

class Rooms {
public:
    int room;
    int single_room;
    int double_room;
    int connecting_room;
    int c1;

    Rooms(int roomNum, int single, int doubleRoom, int connecting)
        : room(roomNum), single_room(single), double_room(doubleRoom), connecting_room(connecting) {}

    void displayInformation() {
        cout << "Room Number: " << room << std::endl;
        cout << "Single Room Capacity: " << single_room << " person(s)" << endl;
        cout << "Double Room Capacity: " << double_room << " person(s)" << endl;
        cout << "Connecting Room Capacity: " << connecting_room << " person(s)" << endl;
    }

    bool isRoomAvailable(int requiredCapacity) {
        int totalCapacity = single_room + 2 * double_room + connecting_room;
        return requiredCapacity <= totalCapacity;
    }

    void bookRoom(int requiredCapacity) {
        if (isRoomAvailable(requiredCapacity)) {
            cout << "Room booked for " << requiredCapacity << " person(s)." << endl;
        } else {
            cout << "Room not available for " << requiredCapacity << " person(s)." << endl;
        }
    }
    
};

class Services {
public:
    int room_laundry;
    int room_makeup;
    int room_eatry;

    Services(int laundry, int makeup, int eatry)
        : room_laundry(laundry), room_makeup(makeup), room_eatry(eatry) {}

    void displayInformation() {
        cout << "Laundry Service: " << room_laundry << endl;
        cout << "Makeup Service: " << room_makeup << endl;
        cout << "Eatry Service: " << room_eatry << endl;
    }

    void performRoomLaundry(Hotel*& head) {
        head->outstanding_payment = head->outstanding_payment + (15 * head->no_of_family_members);
        cout << "Laundry service performed." << endl;
    }

    void performRoomMakeup(Hotel*& head) {
        head->outstanding_payment = head->outstanding_payment + 20;
        cout << "Makeup service performed." << endl;
    }

    void performRoomEatery(Hotel*& head) {
        head->outstanding_payment = head->outstanding_payment + (7 * head->no_of_family_members);
        cout << "Eatery service performed." << endl;
    }
};



class Reservation {
	
public:
    int booking_id;
    int roomnumber;
    string from_date;
    string to_date;
    int services_need;

    Reservation(int bookingId, int roomnumber, const string& fromDate, const string& toDate, int servicesNeed)
        : booking_id(bookingId), roomnumber(roomnumber), from_date(fromDate), to_date(toDate), services_need(servicesNeed) {}

    void displayInformation() {
        cout << "Booking ID: " << booking_id << endl;
        cout << "Room Number: " << roomnumber << endl;
        cout << "From Date: " << from_date << endl;
        cout << "To Date: " << to_date << endl;
        cout << "Services Needed: " << services_need << endl;
    }

    void updateInformation(int newRoomNumber, const string& newFromDate, const string& newToDate, int newServicesNeeded) {
        roomnumber = newRoomNumber;
        from_date = newFromDate;
        to_date = newToDate;
        services_need = newServicesNeeded;
        cout << "Reservation information updated." << endl;
    }
};


class Payment {
public:
    string name;
    int amount;
    string paymentMethod;
    string paymentDate;
    int cash;
    int card;

    Payment(const string& n, int amt, const string& method, const string& date, int cashAmt, int cardAmt)
        : name(n), amount(amt), paymentMethod(method), paymentDate(date), cash(cashAmt), card(cardAmt) {}

    void displayInformation() {
        cout << "Name: " << name << endl;
        cout << "Amount: $" << amount << endl;
        cout << "Payment Method: " << paymentMethod << endl;
        cout << "Payment Date: " << paymentDate << endl;
        cout << "Cash Amount: $" << cash << endl;
        cout << "Card Amount: $" << card << endl;
    }

    void processPayment() {
        cout << "Processing payment..." << endl;
        cout << "Payment processed successfully." << endl;
    }
    
};

class Staff {
public:
    int total_staff;
    int female_staff;
    int male_staff;
    int management_staff;
    int cleaning_staff;

    Staff(int total, int female, int male, int management, int cleaning)
        : total_staff(total), female_staff(female), male_staff(male), management_staff(management), cleaning_staff(cleaning) {}

    void displayInformation() {
        cout << "Total Staff: " << total_staff << endl;
        cout << "Female Staff: " << female_staff << endl;
        cout << "Male Staff: " << male_staff << endl;
        cout << "Management Staff: " << management_staff << endl;
        cout << "Cleaning Staff: " << cleaning_staff << endl;
    }

    void hireStaff(int newFemale, int newMale, int newManagement, int newCleaning) {
        female_staff += newFemale;
        male_staff += newMale;
        management_staff += newManagement;
        cleaning_staff += newCleaning;
        total_staff += newFemale + newMale + newManagement + newCleaning;
        cout << "New staff hired successfully." << endl;
    }

    void terminateStaff(int terminateFemale, int terminateMale, int terminateManagement, int terminateCleaning) {
        if (terminateFemale <= female_staff && terminateMale <= male_staff &&
            terminateManagement <= management_staff && terminateCleaning <= cleaning_staff) {
            female_staff -= terminateFemale;
            male_staff -= terminateMale;
            management_staff -= terminateManagement;
            cleaning_staff -= terminateCleaning;
            total_staff -= terminateFemale + terminateMale + terminateManagement + terminateCleaning;
            cout << "Staff terminated successfully." << endl;
        } else {
            cout << "Cannot terminate more staff than currently employed." << endl;
        }
    }
};

class Node {
public:
    int data;
    Node* next;

    Node(int value) : data(value), next(NULL) {}
};

class Linkedlist {
private:
    Node* head;

public:
    Linkedlist() : head(NULL) {}

    void addNode(int value) {
        Node* newNode = new Node(value);

        if (head == NULL) {
            head = newNode;
        } else {
            Node* current = head;
            while (current->next != NULL) {
                current = current->next;
            }
            current->next = newNode;
        }
    }

    void displayList() {
        Node* current = head;
        while (current != NULL) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};

void makePayment(queue<Payment>& paymentQueue) {
    // Implementation for making payments
}

void savePaymentsToFile(queue<Payment>& paymentQueue) {
    // Implementation for saving payments to a file
}
void processPayment(queue<Payment>& paymentQueue) {
    // Check if there are payments in the queue
    if (paymentQueue.empty()) {
        cout << "No payments to process." << endl;
        return;
    }


    while (!paymentQueue.empty()) {
        Payment currentPayment = paymentQueue.front();

       
        cout << "Processing payment for: " << currentPayment.name << endl;
        currentPayment.displayInformation();

       
        currentPayment.processPayment();

       
        paymentQueue.pop();
    }
}
int main() {
   
    Guest* guestHead = NULL;
    Hotel* hotelHead = NULL;

    
    addathead(guestHead, 101, "John", "Doe");
    addathead(guestHead, 102, "Jane", "Smith");
    addathead(guestHead, 103, "Bob", "Johnson");

    
    cout << "Guest Information:" << endl;
    display(guestHead);

    
    sortrecords(guestHead);

   
    int guestIDToSearch = 102;
    searchinLL(guestHead, guestIDToSearch);

   
    addathead(hotelHead, 4, 7);
    addathead(hotelHead, 2, 3);
    addathead(hotelHead, 6, 5);

    
    cout << "Hotel Information:" << endl;
    display(hotelHead);

    
    Rooms room1(101, 1, 2, 1);
    Services services(3, 2, 1);

   
    int requiredCapacity = 5;
    room1.displayInformation();
    room1.bookRoom(requiredCapacity);

   
    services.performRoomLaundry(hotelHead);
    services.performRoomMakeup(hotelHead);
    services.performRoomEatery(hotelHead);

   
    Reservation reservation1(1, 101, "2024-01-20", "2024-01-25", 2);
    Payment payment1("John Doe", 150, "Credit Card", "2024-01-22", 0, 150);

    cout << "Reservation Information:" << endl;
    reservation1.displayInformation();

    cout << "Payment Information:" << endl;
    payment1.displayInformation();

    queue<Payment> paymentQueue;
    paymentQueue.push(payment1);

    cout << "Processing Payments:" << endl;
    processPayment(paymentQueue);

  
    Linkedlist intList;
    intList.addNode(10);
    intList.addNode(20);
    intList.addNode(30);

    cout << "Linked List of Integers:" << endl;
    intList.displayList();

    return 0;
}

